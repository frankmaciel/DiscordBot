"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const Discord = require("discord.js");
class poll {
    constructor() {
        this._command = "poll";
    }
    help() {
        return "A command for starting a poll";
    }
    isThisCommand(command) {
        return command === this._command;
    }
    runCommand(args, msgObject, client) {
        return __awaiter(this, void 0, void 0, function* () {
            msgObject.delete(0)
                .catch(console.error);
            if (args.length < 1) {
                return;
            }
            let pollEmbed = new Discord.RichEmbed()
                .setTitle(`${msgObject.author.username}'s Poll`)
                .setDescription(args.join(" "));
            msgObject.channel.send("You will only have 10 seconds to answer!")
                .then(msg => {
                msg.delete(11000);
            });
            let pollMessage = yield msgObject.channel.send(pollEmbed)
                .catch(console.error);
            yield pollMessage.react("👍")
                .catch(console.error);
            yield pollMessage.react("👎")
                .catch(console.error);
            const filter = (reaction) => reaction.emoji.name === '👍' || reaction.emoji.name === '👎';
            const results = yield pollMessage.awaitReactions(filter, { time: 10000 });
            let resultsEmbed = new Discord.RichEmbed()
                .setTitle(`${msgObject.author.username}'s Poll Results For ${args.join(" ")}`)
                .addField("👍:", `${(results.get("👍").count) - 1} Votes`)
                .addField("👎:", `${(results.get("👎").count) - 1} Votes`)
                .setColor("RANDOM");
            msgObject.channel.send(resultsEmbed)
                .then(msg => {
                msg.delete(15000);
            });
            pollMessage.delete(0)
                .catch(console.error);
        });
    }
}
exports.default = poll;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicG9sbC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9jb21tYW5kcy9wb2xsLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7QUFBQSxzQ0FBc0M7QUFHdEMsTUFBcUIsSUFBSTtJQUF6QjtRQUVxQixhQUFRLEdBQUcsTUFBTSxDQUFDO0lBZ0V2QyxDQUFDO0lBOURHLElBQUk7UUFFQSxPQUFPLCtCQUErQixDQUFDO0lBQzNDLENBQUM7SUFDRCxhQUFhLENBQUMsT0FBZTtRQUV6QixPQUFPLE9BQU8sS0FBSyxJQUFJLENBQUMsUUFBUSxDQUFBO0lBQ3BDLENBQUM7SUFDSyxVQUFVLENBQUMsSUFBYyxFQUFFLFNBQTBCLEVBQUUsTUFBc0I7O1lBRS9FLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO2lCQUNkLEtBQUssQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUM7WUFHMUIsSUFBRyxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtnQkFBRSxPQUFPO2FBQUU7WUFHL0IsSUFBSSxTQUFTLEdBQUcsSUFBSSxPQUFPLENBQUMsU0FBUyxFQUFFO2lCQUNsQyxRQUFRLENBQUMsR0FBRyxTQUFTLENBQUMsTUFBTSxDQUFDLFFBQVEsU0FBUyxDQUFDO2lCQUMvQyxjQUFjLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFBO1lBRW5DLFNBQVMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLDBDQUEwQyxDQUFDO2lCQUM3RCxJQUFJLENBQUMsR0FBRyxDQUFBLEVBQUU7Z0JBQ04sR0FBdUIsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDM0MsQ0FBQyxDQUFDLENBQUM7WUFHUCxJQUFJLFdBQVcsR0FBRyxNQUFNLFNBQVMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQztpQkFDcEQsS0FBSyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQTtZQUl6QixNQUFPLFdBQStCLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQztpQkFDN0MsS0FBSyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUMxQixNQUFPLFdBQStCLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQztpQkFDN0MsS0FBSyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUcxQixNQUFNLE1BQU0sR0FBRyxDQUFDLFFBQWlDLEVBQUUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsSUFBSSxLQUFLLElBQUksSUFBSSxRQUFRLENBQUMsS0FBSyxDQUFDLElBQUksS0FBSyxJQUFJLENBQUM7WUFFbkgsTUFBTSxPQUFPLEdBQUcsTUFBTyxXQUErQixDQUFDLGNBQWMsQ0FBQyxNQUFNLEVBQUUsRUFBQyxJQUFJLEVBQUUsS0FBSyxFQUFDLENBQUMsQ0FBQztZQUc3RixJQUFJLFlBQVksR0FBRyxJQUFJLE9BQU8sQ0FBQyxTQUFTLEVBQUU7aUJBQ3pDLFFBQVEsQ0FBQyxHQUFHLFNBQVMsQ0FBQyxNQUFNLENBQUMsUUFBUSx1QkFBdUIsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDO2lCQUM3RSxRQUFRLENBQUMsS0FBSyxFQUFFLEdBQUcsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFDLENBQUMsUUFBUSxDQUFDO2lCQUN2RCxRQUFRLENBQUMsS0FBSyxFQUFFLEdBQUcsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFDLENBQUMsUUFBUSxDQUFDO2lCQUN2RCxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUM7WUFFcEIsU0FBUyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDO2lCQUMvQixJQUFJLENBQUMsR0FBRyxDQUFBLEVBQUU7Z0JBQ04sR0FBdUIsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDM0MsQ0FBQyxDQUFDLENBQUM7WUFHTixXQUErQixDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7aUJBQ3JDLEtBQUssQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUM7UUFLOUIsQ0FBQztLQUFBO0NBQ0o7QUFsRUQsdUJBa0VDIn0=