"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const LeagueJS = require("../../LeagueJS/lib/LeagueJS.js");
class pastfive {
    constructor() {
        this._command = "pastfive";
    }
    help() {
        return "Explain what the command does";
    }
    isThisCommand(command) {
        return command === this._command;
    }
    runCommand(args, msgObject, client) {
        return __awaiter(this, void 0, void 0, function* () {
            let apiKey = "RGAPI-59930485-ced3-4e19-86d1-5a1c4ae03850";
            let command = args.slice(0) || "";
            if (command[0] == "help") {
                msgObject.channel.send("Usage: !pastfive [region] [summonername]")
                    .then(msg => {
                    msg.delete(20000)
                        .catch(console.error);
                });
            }
            else {
                const leagueJs = new LeagueJS(apiKey, { PLATFORM_ID: command[0] });
                let regionEntered = command[0];
                let summonerEntered = command[1];
                var summonerInfo;
                var matchList;
                yield leagueJs.Summoner
                    .gettingByName(summonerEntered)
                    .then(data => {
                    'use strict';
                    summonerInfo = data;
                })
                    .catch(err => {
                    'use strict';
                    console.log(err);
                });
                yield msgObject.channel.send(`Summoner Name: ${summonerInfo.name} \nSummoner Level: ${summonerInfo.summonerLevel}\n\n`)
                    .then(msg => {
                    msg.delete(50000)
                        .catch(console.error);
                });
                yield leagueJs.Match
                    .gettingListByAccount(summonerInfo.accountId)
                    .then(data => {
                    'use strict';
                    matchList = data;
                })
                    .catch(err => {
                    'use strict';
                    console.log(err);
                });
                for (var i = 0; i < 5; i++) {
                    let position;
                    let participant;
                    let championNum = parseInt(matchList.matches[i].champion);
                    let championName = idLookup(championNum);
                    const fullData = yield leagueJs.Match.gettingById(matchList.matches[i].gameId);
                    for (var j = 0; j < 10; j++) {
                        if (fullData.participants[j].championId === matchList.matches[i].champion) {
                            participant = fullData.participants[j];
                        }
                    }
                    if (matchList.matches[i].lane == "BOTTOM") {
                        position = "Bottom";
                    }
                    else if (matchList.matches[i].lane == "TOP") {
                        position = "Top";
                    }
                    else if (matchList.matches[i].lane == "JUNGLE") {
                        position = "Jungle";
                    }
                    else if (matchList.matches[i].lane == "MID") {
                        position = "Mid";
                    }
                    else if (matchList.matches[i].lane == "NONE") {
                        position = "Support";
                    }
                    var day = i + 1;
                    var playerStats = participant.stats;
                    yield msgObject.channel.send(`Day: ` + day + `\nPosition: ${position} \nChampion: ${championName} \nK/D/A:\n${playerStats.kills}/${playerStats.deaths}/${playerStats.assists}\n\n`)
                        .then(msg => {
                        msg.delete(100000)
                            .catch(console.error);
                    });
                }
            }
        });
    }
}
exports.default = pastfive;
function idLookup(id) {
    switch (id) {
        case 266:
            return "Aatrox";
            break;
        case 412:
            return "Thresh";
            break;
        case 23:
            return "Tryndamere";
            break;
        case 79:
            return "Gragas";
            break;
        case 69:
            return "Cassiopeia";
            break;
        case 136:
            return "Aurelion Sol";
            break;
        case 13:
            return "Ryze";
            break;
        case 78:
            return "Poppy";
            break;
        case 14:
            return "Sion";
            break;
        case 1:
            return "Annie";
            break;
        case 202:
            return "Jhin";
            break;
        case 43:
            return "Karma";
            break;
        case 111:
            return "Nautilus";
            break;
        case 240:
            return "Kled";
            break;
        case 99:
            return "Lux";
            break;
        case 103:
            return "Ahri";
            break;
        case 2:
            return "Olaf";
            break;
        case 112:
            return "Viktor";
            break;
        case 34:
            return "Anivia";
            break;
        case 27:
            return "Singed";
            break;
        case 86:
            return "Garen";
            break;
        case 127:
            return "Lissandra";
            break;
        case 57:
            return "Maokai";
            break;
        case 25:
            return "Morgana";
            break;
        case 28:
            return "Evelynn";
            break;
        case 105:
            return "Fizz";
            break;
        case 74:
            return "Heimerdinger";
            break;
        case 238:
            return "Zed";
            break;
        case 68:
            return "Rumble";
            break;
        case 82:
            return "Mordekaiser";
            break;
        case 37:
            return "Sona";
            break;
        case 96:
            return "Kog'Maw";
            break;
        case 55:
            return "Katarina";
            break;
        case 117:
            return "Lulu";
            break;
        case 22:
            return "Ashe";
            break;
        case 30:
            return "Karthus";
            break;
        case 12:
            return "Alistar";
            break;
        case 122:
            return "Darius";
            break;
        case 67:
            return "Vayne";
            break;
        case 110:
            return "Varus";
            break;
        case 77:
            return "Udyr";
            break;
        case 89:
            return "Leona";
            break;
        case 126:
            return "Jayce";
            break;
        case 134:
            return "Syndra";
            break;
        case 80:
            return "Pantheon";
            break;
        case 92:
            return "Riven";
            break;
        case 121:
            return "Kha'Zix";
            break;
        case 42:
            return "Corki";
            break;
        case 268:
            return "Azir";
            break;
        case 51:
            return "Caitlyn";
            break;
        case 76:
            return "Nidalee";
            break;
        case 85:
            return "Kennen";
            break;
        case 3:
            return "Galio";
            break;
        case 45:
            return "Veigar";
            break;
        case 432:
            return "Bard";
            break;
        case 150:
            return "Gnar";
            break;
        case 90:
            return "Malzahar";
            break;
        case 104:
            return "Graves";
            break;
        case 254:
            return "Vi";
            break;
        case 10:
            return "Kayle";
            break;
        case 39:
            return "Irelia";
            break;
        case 64:
            return "Lee Sin";
            break;
        case 420:
            return "Illaoi";
            break;
        case 60:
            return "Elise";
            break;
        case 106:
            return "Volibear";
            break;
        case 20:
            return "Nunu";
            break;
        case 4:
            return "Twisted Fate";
            break;
        case 24:
            return "Jax";
            break;
        case 102:
            return "Shyvana";
            break;
        case 429:
            return "Kalista";
            break;
        case 36:
            return "Dr. Mundo";
            break;
        case 427:
            return "Ivern";
            break;
        case 131:
            return "Diana";
            break;
        case 223:
            return "Tahm Kench";
            break;
        case 63:
            return "Brand";
            break;
        case 113:
            return "Sejuani";
            break;
        case 8:
            return "Vladimir";
            break;
        case 154:
            return "Zac";
            break;
        case 421:
            return "Rek'Sai";
            break;
        case 133:
            return "Quinn";
            break;
        case 84:
            return "Akali";
            break;
        case 163:
            return "Taliyah";
            break;
        case 18:
            return "Tristana";
            break;
        case 120:
            return "Hecarim";
            break;
        case 15:
            return "Sivir";
            break;
        case 236:
            return "Lucian";
            break;
        case 107:
            return "Rengar";
            break;
        case 19:
            return "Warwick";
            break;
        case 72:
            return "Skarner";
            break;
        case 54:
            return "Malphite";
            break;
        case 157:
            return "Yasuo";
            break;
        case 101:
            return "Xerath";
            break;
        case 17:
            return "Teemo";
            break;
        case 75:
            return "Nasus";
            break;
        case 58:
            return "Renekton";
            break;
        case 119:
            return "Draven";
            break;
        case 35:
            return "Shaco";
            break;
        case 50:
            return "Swain";
            break;
        case 91:
            return "Talon";
            break;
        case 40:
            return "Janna";
            break;
        case 115:
            return "Ziggs";
            break;
        case 245:
            return "Ekko";
            break;
        case 61:
            return "Orianna";
            break;
        case 114:
            return "Fiora";
            break;
        case 9:
            return "Fiddlesticks";
            break;
        case 31:
            return "Cho'Gath";
            break;
        case 33:
            return "Rammus";
            break;
        case 7:
            return "LeBlanc";
            break;
        case 16:
            return "Soraka";
            break;
        case 26:
            return "Zilean";
            break;
        case 56:
            return "Nocturne";
            break;
        case 222:
            return "Jinx";
            break;
        case 83:
            return "Yorick";
            break;
        case 6:
            return "Urgot";
            break;
        case 203:
            return "Kindred";
            break;
        case 21:
            return "Miss Fortune";
            break;
        case 62:
            return "Wukong";
            break;
        case 53:
            return "Blitzcrank";
            break;
        case 98:
            return "Shen";
            break;
        case 201:
            return "Braum";
            break;
        case 5:
            return "Xin Zhao";
            break;
        case 29:
            return "Twitch";
            break;
        case 11:
            return "Master Yi";
            break;
        case 44:
            return "Taric";
            break;
        case 32:
            return "Amumu";
            break;
        case 41:
            return "Gangplank";
            break;
        case 48:
            return "Trundle";
            break;
        case 38:
            return "Kassadin";
            break;
        case 161:
            return "Vel'Koz";
            break;
        case 143:
            return "Zyra";
            break;
        case 267:
            return "Nami";
            break;
        case 59:
            return "Jarvan IV";
            break;
        case 81:
            return "Ezreal";
            break;
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGFzdGZpdmUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9zcmMvY29tbWFuZHMvcGFzdGZpdmUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQUlBLDJEQUEyRDtBQU0zRCxNQUFxQixRQUFRO0lBQTdCO1FBRXFCLGFBQVEsR0FBRyxVQUFVLENBQUM7SUF3RzNDLENBQUM7SUF0R0csSUFBSTtRQUVBLE9BQU8sK0JBQStCLENBQUE7SUFDMUMsQ0FBQztJQUNELGFBQWEsQ0FBQyxPQUFlO1FBRXpCLE9BQU8sT0FBTyxLQUFLLElBQUksQ0FBQyxRQUFRLENBQUE7SUFDcEMsQ0FBQztJQUNLLFVBQVUsQ0FBQyxJQUFjLEVBQUUsU0FBMEIsRUFBRSxNQUFzQjs7WUFFL0UsSUFBSSxNQUFNLEdBQUcsNENBQTRDLENBQUM7WUFDMUQsSUFBSSxPQUFPLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7WUFFbEMsSUFBSSxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUksTUFBTSxFQUFFO2dCQUN0QixTQUFTLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQywwQ0FBMEMsQ0FBQztxQkFDN0QsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFO29CQUNQLEdBQXVCLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQzt5QkFDakMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFDOUIsQ0FBQyxDQUFDLENBQUM7YUFDVjtpQkFDSTtnQkFDRCxNQUFNLFFBQVEsR0FBRyxJQUFJLFFBQVEsQ0FBQyxNQUFNLEVBQUUsRUFBRSxXQUFXLEVBQUUsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQztnQkFDbkUsSUFBSSxhQUFhLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUMvQixJQUFJLGVBQWUsR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ2pDLElBQUksWUFBWSxDQUFDO2dCQUNqQixJQUFJLFNBQVMsQ0FBQztnQkFFZCxNQUFNLFFBQVEsQ0FBQyxRQUFRO3FCQUNsQixhQUFhLENBQUMsZUFBZSxDQUFDO3FCQUM5QixJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7b0JBQ1QsWUFBWSxDQUFDO29CQUNiLFlBQVksR0FBRyxJQUFJLENBQUM7Z0JBQ3hCLENBQUMsQ0FBQztxQkFDRCxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUU7b0JBQ1QsWUFBWSxDQUFDO29CQUNiLE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQ3JCLENBQUMsQ0FBQyxDQUFDO2dCQUVQLE1BQU0sU0FBUyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsa0JBQWtCLFlBQVksQ0FBQyxJQUFJLHNCQUFzQixZQUFZLENBQUMsYUFBYSxNQUFNLENBQUM7cUJBQ2xILElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRTtvQkFDUCxHQUF1QixDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUM7eUJBQ2pDLEtBQUssQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQzlCLENBQUMsQ0FBQyxDQUFDO2dCQUVQLE1BQU0sUUFBUSxDQUFDLEtBQUs7cUJBQ2Ysb0JBQW9CLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQztxQkFDNUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO29CQUNULFlBQVksQ0FBQztvQkFDYixTQUFTLEdBQUcsSUFBSSxDQUFDO2dCQUNyQixDQUFDLENBQUM7cUJBQ0QsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFFO29CQUNULFlBQVksQ0FBQztvQkFDYixPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUNyQixDQUFDLENBQUMsQ0FBQztnQkFFUCxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFO29CQUN4QixJQUFJLFFBQVEsQ0FBQztvQkFDYixJQUFJLFdBQVcsQ0FBQztvQkFFaEIsSUFBSSxXQUFXLEdBQUcsUUFBUSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7b0JBQzFELElBQUksWUFBWSxHQUFHLFFBQVEsQ0FBQyxXQUFXLENBQUMsQ0FBQztvQkFFekMsTUFBTSxRQUFRLEdBQUcsTUFBTSxRQUFRLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUMvRSxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsRUFBRSxFQUFFLENBQUMsRUFBRSxFQUMzQjt3QkFDSSxJQUFJLFFBQVEsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxLQUFLLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxFQUFFOzRCQUN2RSxXQUFXLEdBQUcsUUFBUSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQzt5QkFDMUM7cUJBQ0o7b0JBR0QsSUFBSSxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksSUFBSSxRQUFRLEVBQUU7d0JBQ3ZDLFFBQVEsR0FBRyxRQUFRLENBQUM7cUJBQ3ZCO3lCQUNJLElBQUksU0FBUyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLElBQUksS0FBSyxFQUFFO3dCQUN6QyxRQUFRLEdBQUcsS0FBSyxDQUFDO3FCQUNwQjt5QkFDSSxJQUFJLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxJQUFJLFFBQVEsRUFBRTt3QkFDNUMsUUFBUSxHQUFHLFFBQVEsQ0FBQztxQkFDdkI7eUJBQ0ksSUFBSSxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksSUFBSSxLQUFLLEVBQUU7d0JBQ3pDLFFBQVEsR0FBRyxLQUFLLENBQUM7cUJBQ3BCO3lCQUNJLElBQUksU0FBUyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLElBQUksTUFBTSxFQUFFO3dCQUMxQyxRQUFRLEdBQUcsU0FBUyxDQUFDO3FCQUN4QjtvQkFFRCxJQUFJLEdBQUcsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO29CQUNoQixJQUFJLFdBQVcsR0FBRyxXQUFXLENBQUMsS0FBSyxDQUFDO29CQUNwQyxNQUFNLFNBQVMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLE9BQU8sR0FBRyxHQUFHLEdBQUUsZUFBZSxRQUFRLGdCQUFnQixZQUFZLGNBQWMsV0FBVyxDQUFDLEtBQUssSUFBSSxXQUFXLENBQUMsTUFBTSxJQUFJLFdBQVcsQ0FBQyxPQUFPLE1BQU0sQ0FBQzt5QkFDN0ssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFO3dCQUNQLEdBQXVCLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQzs2QkFDbEMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDOUIsQ0FBQyxDQUFDLENBQUM7aUJBRVY7YUFHSjtRQUVMLENBQUM7S0FBQTtDQUVKO0FBMUdELDJCQTBHQztBQUNELFNBQVMsUUFBUSxDQUFDLEVBQUU7SUFDaEIsUUFBUSxFQUFFLEVBQUU7UUFDUixLQUFLLEdBQUc7WUFBRSxPQUFPLFFBQVEsQ0FBQztZQUFDLE1BQU07UUFDakMsS0FBSyxHQUFHO1lBQUUsT0FBTyxRQUFRLENBQUM7WUFBQyxNQUFNO1FBQ2pDLEtBQUssRUFBRTtZQUFFLE9BQU8sWUFBWSxDQUFDO1lBQUMsTUFBTTtRQUNwQyxLQUFLLEVBQUU7WUFBRSxPQUFPLFFBQVEsQ0FBQztZQUFDLE1BQU07UUFDaEMsS0FBSyxFQUFFO1lBQUUsT0FBTyxZQUFZLENBQUM7WUFBQyxNQUFNO1FBQ3BDLEtBQUssR0FBRztZQUFFLE9BQU8sY0FBYyxDQUFDO1lBQUMsTUFBTTtRQUN2QyxLQUFLLEVBQUU7WUFBRSxPQUFPLE1BQU0sQ0FBQztZQUFDLE1BQU07UUFDOUIsS0FBSyxFQUFFO1lBQUUsT0FBTyxPQUFPLENBQUM7WUFBQyxNQUFNO1FBQy9CLEtBQUssRUFBRTtZQUFFLE9BQU8sTUFBTSxDQUFDO1lBQUMsTUFBTTtRQUM5QixLQUFLLENBQUM7WUFBRSxPQUFPLE9BQU8sQ0FBQztZQUFDLE1BQU07UUFDOUIsS0FBSyxHQUFHO1lBQUUsT0FBTyxNQUFNLENBQUM7WUFBQyxNQUFNO1FBQy9CLEtBQUssRUFBRTtZQUFFLE9BQU8sT0FBTyxDQUFDO1lBQUMsTUFBTTtRQUMvQixLQUFLLEdBQUc7WUFBRSxPQUFPLFVBQVUsQ0FBQztZQUFDLE1BQU07UUFDbkMsS0FBSyxHQUFHO1lBQUUsT0FBTyxNQUFNLENBQUM7WUFBQyxNQUFNO1FBQy9CLEtBQUssRUFBRTtZQUFFLE9BQU8sS0FBSyxDQUFDO1lBQUMsTUFBTTtRQUM3QixLQUFLLEdBQUc7WUFBRSxPQUFPLE1BQU0sQ0FBQztZQUFDLE1BQU07UUFDL0IsS0FBSyxDQUFDO1lBQUUsT0FBTyxNQUFNLENBQUM7WUFBQyxNQUFNO1FBQzdCLEtBQUssR0FBRztZQUFFLE9BQU8sUUFBUSxDQUFDO1lBQUMsTUFBTTtRQUNqQyxLQUFLLEVBQUU7WUFBRSxPQUFPLFFBQVEsQ0FBQztZQUFDLE1BQU07UUFDaEMsS0FBSyxFQUFFO1lBQUUsT0FBTyxRQUFRLENBQUM7WUFBQyxNQUFNO1FBQ2hDLEtBQUssRUFBRTtZQUFFLE9BQU8sT0FBTyxDQUFDO1lBQUMsTUFBTTtRQUMvQixLQUFLLEdBQUc7WUFBRSxPQUFPLFdBQVcsQ0FBQztZQUFDLE1BQU07UUFDcEMsS0FBSyxFQUFFO1lBQUUsT0FBTyxRQUFRLENBQUM7WUFBQyxNQUFNO1FBQ2hDLEtBQUssRUFBRTtZQUFFLE9BQU8sU0FBUyxDQUFDO1lBQUMsTUFBTTtRQUNqQyxLQUFLLEVBQUU7WUFBRSxPQUFPLFNBQVMsQ0FBQztZQUFDLE1BQU07UUFDakMsS0FBSyxHQUFHO1lBQUUsT0FBTyxNQUFNLENBQUM7WUFBQyxNQUFNO1FBQy9CLEtBQUssRUFBRTtZQUFFLE9BQU8sY0FBYyxDQUFDO1lBQUMsTUFBTTtRQUN0QyxLQUFLLEdBQUc7WUFBRSxPQUFPLEtBQUssQ0FBQztZQUFDLE1BQU07UUFDOUIsS0FBSyxFQUFFO1lBQUUsT0FBTyxRQUFRLENBQUM7WUFBQyxNQUFNO1FBQ2hDLEtBQUssRUFBRTtZQUFFLE9BQU8sYUFBYSxDQUFDO1lBQUMsTUFBTTtRQUNyQyxLQUFLLEVBQUU7WUFBRSxPQUFPLE1BQU0sQ0FBQztZQUFDLE1BQU07UUFDOUIsS0FBSyxFQUFFO1lBQUUsT0FBTyxTQUFTLENBQUM7WUFBQyxNQUFNO1FBQ2pDLEtBQUssRUFBRTtZQUFFLE9BQU8sVUFBVSxDQUFDO1lBQUMsTUFBTTtRQUNsQyxLQUFLLEdBQUc7WUFBRSxPQUFPLE1BQU0sQ0FBQztZQUFDLE1BQU07UUFDL0IsS0FBSyxFQUFFO1lBQUUsT0FBTyxNQUFNLENBQUM7WUFBQyxNQUFNO1FBQzlCLEtBQUssRUFBRTtZQUFFLE9BQU8sU0FBUyxDQUFDO1lBQUMsTUFBTTtRQUNqQyxLQUFLLEVBQUU7WUFBRSxPQUFPLFNBQVMsQ0FBQztZQUFDLE1BQU07UUFDakMsS0FBSyxHQUFHO1lBQUUsT0FBTyxRQUFRLENBQUM7WUFBQyxNQUFNO1FBQ2pDLEtBQUssRUFBRTtZQUFFLE9BQU8sT0FBTyxDQUFDO1lBQUMsTUFBTTtRQUMvQixLQUFLLEdBQUc7WUFBRSxPQUFPLE9BQU8sQ0FBQztZQUFDLE1BQU07UUFDaEMsS0FBSyxFQUFFO1lBQUUsT0FBTyxNQUFNLENBQUM7WUFBQyxNQUFNO1FBQzlCLEtBQUssRUFBRTtZQUFFLE9BQU8sT0FBTyxDQUFDO1lBQUMsTUFBTTtRQUMvQixLQUFLLEdBQUc7WUFBRSxPQUFPLE9BQU8sQ0FBQztZQUFDLE1BQU07UUFDaEMsS0FBSyxHQUFHO1lBQUUsT0FBTyxRQUFRLENBQUM7WUFBQyxNQUFNO1FBQ2pDLEtBQUssRUFBRTtZQUFFLE9BQU8sVUFBVSxDQUFDO1lBQUMsTUFBTTtRQUNsQyxLQUFLLEVBQUU7WUFBRSxPQUFPLE9BQU8sQ0FBQztZQUFDLE1BQU07UUFDL0IsS0FBSyxHQUFHO1lBQUUsT0FBTyxTQUFTLENBQUM7WUFBQyxNQUFNO1FBQ2xDLEtBQUssRUFBRTtZQUFFLE9BQU8sT0FBTyxDQUFDO1lBQUMsTUFBTTtRQUMvQixLQUFLLEdBQUc7WUFBRSxPQUFPLE1BQU0sQ0FBQztZQUFDLE1BQU07UUFDL0IsS0FBSyxFQUFFO1lBQUUsT0FBTyxTQUFTLENBQUM7WUFBQyxNQUFNO1FBQ2pDLEtBQUssRUFBRTtZQUFFLE9BQU8sU0FBUyxDQUFDO1lBQUMsTUFBTTtRQUNqQyxLQUFLLEVBQUU7WUFBRSxPQUFPLFFBQVEsQ0FBQztZQUFDLE1BQU07UUFDaEMsS0FBSyxDQUFDO1lBQUUsT0FBTyxPQUFPLENBQUM7WUFBQyxNQUFNO1FBQzlCLEtBQUssRUFBRTtZQUFFLE9BQU8sUUFBUSxDQUFDO1lBQUMsTUFBTTtRQUNoQyxLQUFLLEdBQUc7WUFBRSxPQUFPLE1BQU0sQ0FBQztZQUFDLE1BQU07UUFDL0IsS0FBSyxHQUFHO1lBQUUsT0FBTyxNQUFNLENBQUM7WUFBQyxNQUFNO1FBQy9CLEtBQUssRUFBRTtZQUFFLE9BQU8sVUFBVSxDQUFDO1lBQUMsTUFBTTtRQUNsQyxLQUFLLEdBQUc7WUFBRSxPQUFPLFFBQVEsQ0FBQztZQUFDLE1BQU07UUFDakMsS0FBSyxHQUFHO1lBQUUsT0FBTyxJQUFJLENBQUM7WUFBQyxNQUFNO1FBQzdCLEtBQUssRUFBRTtZQUFFLE9BQU8sT0FBTyxDQUFDO1lBQUMsTUFBTTtRQUMvQixLQUFLLEVBQUU7WUFBRSxPQUFPLFFBQVEsQ0FBQztZQUFDLE1BQU07UUFDaEMsS0FBSyxFQUFFO1lBQUUsT0FBTyxTQUFTLENBQUM7WUFBQyxNQUFNO1FBQ2pDLEtBQUssR0FBRztZQUFFLE9BQU8sUUFBUSxDQUFDO1lBQUMsTUFBTTtRQUNqQyxLQUFLLEVBQUU7WUFBRSxPQUFPLE9BQU8sQ0FBQztZQUFDLE1BQU07UUFDL0IsS0FBSyxHQUFHO1lBQUUsT0FBTyxVQUFVLENBQUM7WUFBQyxNQUFNO1FBQ25DLEtBQUssRUFBRTtZQUFFLE9BQU8sTUFBTSxDQUFDO1lBQUMsTUFBTTtRQUM5QixLQUFLLENBQUM7WUFBRSxPQUFPLGNBQWMsQ0FBQztZQUFDLE1BQU07UUFDckMsS0FBSyxFQUFFO1lBQUUsT0FBTyxLQUFLLENBQUM7WUFBQyxNQUFNO1FBQzdCLEtBQUssR0FBRztZQUFFLE9BQU8sU0FBUyxDQUFDO1lBQUMsTUFBTTtRQUNsQyxLQUFLLEdBQUc7WUFBRSxPQUFPLFNBQVMsQ0FBQztZQUFDLE1BQU07UUFDbEMsS0FBSyxFQUFFO1lBQUUsT0FBTyxXQUFXLENBQUM7WUFBQyxNQUFNO1FBQ25DLEtBQUssR0FBRztZQUFFLE9BQU8sT0FBTyxDQUFDO1lBQUMsTUFBTTtRQUNoQyxLQUFLLEdBQUc7WUFBRSxPQUFPLE9BQU8sQ0FBQztZQUFDLE1BQU07UUFDaEMsS0FBSyxHQUFHO1lBQUUsT0FBTyxZQUFZLENBQUM7WUFBQyxNQUFNO1FBQ3JDLEtBQUssRUFBRTtZQUFFLE9BQU8sT0FBTyxDQUFDO1lBQUMsTUFBTTtRQUMvQixLQUFLLEdBQUc7WUFBRSxPQUFPLFNBQVMsQ0FBQztZQUFDLE1BQU07UUFDbEMsS0FBSyxDQUFDO1lBQUUsT0FBTyxVQUFVLENBQUM7WUFBQyxNQUFNO1FBQ2pDLEtBQUssR0FBRztZQUFFLE9BQU8sS0FBSyxDQUFDO1lBQUMsTUFBTTtRQUM5QixLQUFLLEdBQUc7WUFBRSxPQUFPLFNBQVMsQ0FBQztZQUFDLE1BQU07UUFDbEMsS0FBSyxHQUFHO1lBQUUsT0FBTyxPQUFPLENBQUM7WUFBQyxNQUFNO1FBQ2hDLEtBQUssRUFBRTtZQUFFLE9BQU8sT0FBTyxDQUFDO1lBQUMsTUFBTTtRQUMvQixLQUFLLEdBQUc7WUFBRSxPQUFPLFNBQVMsQ0FBQztZQUFDLE1BQU07UUFDbEMsS0FBSyxFQUFFO1lBQUUsT0FBTyxVQUFVLENBQUM7WUFBQyxNQUFNO1FBQ2xDLEtBQUssR0FBRztZQUFFLE9BQU8sU0FBUyxDQUFDO1lBQUMsTUFBTTtRQUNsQyxLQUFLLEVBQUU7WUFBRSxPQUFPLE9BQU8sQ0FBQztZQUFDLE1BQU07UUFDL0IsS0FBSyxHQUFHO1lBQUUsT0FBTyxRQUFRLENBQUM7WUFBQyxNQUFNO1FBQ2pDLEtBQUssR0FBRztZQUFFLE9BQU8sUUFBUSxDQUFDO1lBQUMsTUFBTTtRQUNqQyxLQUFLLEVBQUU7WUFBRSxPQUFPLFNBQVMsQ0FBQztZQUFDLE1BQU07UUFDakMsS0FBSyxFQUFFO1lBQUUsT0FBTyxTQUFTLENBQUM7WUFBQyxNQUFNO1FBQ2pDLEtBQUssRUFBRTtZQUFFLE9BQU8sVUFBVSxDQUFDO1lBQUMsTUFBTTtRQUNsQyxLQUFLLEdBQUc7WUFBRSxPQUFPLE9BQU8sQ0FBQztZQUFDLE1BQU07UUFDaEMsS0FBSyxHQUFHO1lBQUUsT0FBTyxRQUFRLENBQUM7WUFBQyxNQUFNO1FBQ2pDLEtBQUssRUFBRTtZQUFFLE9BQU8sT0FBTyxDQUFDO1lBQUMsTUFBTTtRQUMvQixLQUFLLEVBQUU7WUFBRSxPQUFPLE9BQU8sQ0FBQztZQUFDLE1BQU07UUFDL0IsS0FBSyxFQUFFO1lBQUUsT0FBTyxVQUFVLENBQUM7WUFBQyxNQUFNO1FBQ2xDLEtBQUssR0FBRztZQUFFLE9BQU8sUUFBUSxDQUFDO1lBQUMsTUFBTTtRQUNqQyxLQUFLLEVBQUU7WUFBRSxPQUFPLE9BQU8sQ0FBQztZQUFDLE1BQU07UUFDL0IsS0FBSyxFQUFFO1lBQUUsT0FBTyxPQUFPLENBQUM7WUFBQyxNQUFNO1FBQy9CLEtBQUssRUFBRTtZQUFFLE9BQU8sT0FBTyxDQUFDO1lBQUMsTUFBTTtRQUMvQixLQUFLLEVBQUU7WUFBRSxPQUFPLE9BQU8sQ0FBQztZQUFDLE1BQU07UUFDL0IsS0FBSyxHQUFHO1lBQUUsT0FBTyxPQUFPLENBQUM7WUFBQyxNQUFNO1FBQ2hDLEtBQUssR0FBRztZQUFFLE9BQU8sTUFBTSxDQUFDO1lBQUMsTUFBTTtRQUMvQixLQUFLLEVBQUU7WUFBRSxPQUFPLFNBQVMsQ0FBQztZQUFDLE1BQU07UUFDakMsS0FBSyxHQUFHO1lBQUUsT0FBTyxPQUFPLENBQUM7WUFBQyxNQUFNO1FBQ2hDLEtBQUssQ0FBQztZQUFFLE9BQU8sY0FBYyxDQUFDO1lBQUMsTUFBTTtRQUNyQyxLQUFLLEVBQUU7WUFBRSxPQUFPLFVBQVUsQ0FBQztZQUFDLE1BQU07UUFDbEMsS0FBSyxFQUFFO1lBQUUsT0FBTyxRQUFRLENBQUM7WUFBQyxNQUFNO1FBQ2hDLEtBQUssQ0FBQztZQUFFLE9BQU8sU0FBUyxDQUFDO1lBQUMsTUFBTTtRQUNoQyxLQUFLLEVBQUU7WUFBRSxPQUFPLFFBQVEsQ0FBQztZQUFDLE1BQU07UUFDaEMsS0FBSyxFQUFFO1lBQUUsT0FBTyxRQUFRLENBQUM7WUFBQyxNQUFNO1FBQ2hDLEtBQUssRUFBRTtZQUFFLE9BQU8sVUFBVSxDQUFDO1lBQUMsTUFBTTtRQUNsQyxLQUFLLEdBQUc7WUFBRSxPQUFPLE1BQU0sQ0FBQztZQUFDLE1BQU07UUFDL0IsS0FBSyxFQUFFO1lBQUUsT0FBTyxRQUFRLENBQUM7WUFBQyxNQUFNO1FBQ2hDLEtBQUssQ0FBQztZQUFFLE9BQU8sT0FBTyxDQUFDO1lBQUMsTUFBTTtRQUM5QixLQUFLLEdBQUc7WUFBRSxPQUFPLFNBQVMsQ0FBQztZQUFDLE1BQU07UUFDbEMsS0FBSyxFQUFFO1lBQUUsT0FBTyxjQUFjLENBQUM7WUFBQyxNQUFNO1FBQ3RDLEtBQUssRUFBRTtZQUFFLE9BQU8sUUFBUSxDQUFDO1lBQUMsTUFBTTtRQUNoQyxLQUFLLEVBQUU7WUFBRSxPQUFPLFlBQVksQ0FBQztZQUFDLE1BQU07UUFDcEMsS0FBSyxFQUFFO1lBQUUsT0FBTyxNQUFNLENBQUM7WUFBQyxNQUFNO1FBQzlCLEtBQUssR0FBRztZQUFFLE9BQU8sT0FBTyxDQUFDO1lBQUMsTUFBTTtRQUNoQyxLQUFLLENBQUM7WUFBRSxPQUFPLFVBQVUsQ0FBQztZQUFDLE1BQU07UUFDakMsS0FBSyxFQUFFO1lBQUUsT0FBTyxRQUFRLENBQUM7WUFBQyxNQUFNO1FBQ2hDLEtBQUssRUFBRTtZQUFFLE9BQU8sV0FBVyxDQUFDO1lBQUMsTUFBTTtRQUNuQyxLQUFLLEVBQUU7WUFBRSxPQUFPLE9BQU8sQ0FBQztZQUFDLE1BQU07UUFDL0IsS0FBSyxFQUFFO1lBQUUsT0FBTyxPQUFPLENBQUM7WUFBQyxNQUFNO1FBQy9CLEtBQUssRUFBRTtZQUFFLE9BQU8sV0FBVyxDQUFDO1lBQUMsTUFBTTtRQUNuQyxLQUFLLEVBQUU7WUFBRSxPQUFPLFNBQVMsQ0FBQztZQUFDLE1BQU07UUFDakMsS0FBSyxFQUFFO1lBQUUsT0FBTyxVQUFVLENBQUM7WUFBQyxNQUFNO1FBQ2xDLEtBQUssR0FBRztZQUFFLE9BQU8sU0FBUyxDQUFDO1lBQUMsTUFBTTtRQUNsQyxLQUFLLEdBQUc7WUFBRSxPQUFPLE1BQU0sQ0FBQztZQUFDLE1BQU07UUFDL0IsS0FBSyxHQUFHO1lBQUUsT0FBTyxNQUFNLENBQUM7WUFBQyxNQUFNO1FBQy9CLEtBQUssRUFBRTtZQUFFLE9BQU8sV0FBVyxDQUFDO1lBQUMsTUFBTTtRQUNuQyxLQUFLLEVBQUU7WUFBRSxPQUFPLFFBQVEsQ0FBQztZQUFDLE1BQU07S0FDbkM7QUFFTCxDQUFDIn0=