"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = {
    "token": "NTcyMjI3MTU3NjgyNjgzOTE2.XMZOOw.mDAu35gZnkpkanindQddy5cARTY",
    "prefix": "!",
    "commands": [
        "kick",
        "purge",
        "serverinfo",
        "help",
        "poll",
        "play",
        "pastfive",
        "pastgame",
    ]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29uZmlnLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vc3JjL2NvbmZpZy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFXLFFBQUEsTUFBTSxHQUFHO0lBQ2hCLE9BQU8sRUFBRSw2REFBNkQ7SUFDdEUsUUFBUSxFQUFFLEdBQUc7SUFDYixVQUFVLEVBQUU7UUFDUixNQUFNO1FBQ04sT0FBTztRQUNQLFlBQVk7UUFDWixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixVQUFVO1FBQ1YsVUFBVTtLQUNiO0NBQ0osQ0FBQSJ9