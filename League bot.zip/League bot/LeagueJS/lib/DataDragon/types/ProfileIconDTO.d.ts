import {ImageDTO} from './ImageDTO';

export interface ProfileIconDataDTO {
	id: number,
	image: ImageDTO
}