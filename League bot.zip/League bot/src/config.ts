export let config = { // creating a variable in which we can import for later use
    "token": "NTcyMjI3MTU3NjgyNjgzOTE2.XMZOOw.mDAu35gZnkpkanindQddy5cARTY",
    "prefix": "!",
    "commands": [
        "kick",
        "purge",
        "serverinfo",
        "help",
        "poll",
        "play",
        "pastfive",
        "pastgame",
    ]
}