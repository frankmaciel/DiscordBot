import * as Discord from "discord.js"; // import all from discord.js as Discord
import * as ConfigFile from "./config"; //import all from ./config as ConfigFile
import { IBotCommand } from "./api";

const client: Discord.Client = new Discord.Client(); // Create new variable client of type Discord.Client

let commands: IBotCommand[] = [];

loadCommands(`${__dirname}/commands`);



client.on("ready", () => { // ()=> is lamda notation meaning when this event is called, do this
    // Let's us know that the bot is online
    console.log("League Bot Has Connected");
    client.guilds.forEach((guild) =>{
        console.log("- " + guild.name);
    })
    //Set the bot's activity
    client.user.setActivity("You", {type: "LISTENING"});
    
    
})

client.on("guildMemberRemove", member=>{ // Need to fix this
    member.send("Sorry you had to go :(");
    let welcomeChannel = member.guild.channels.find(channel => channel.name === "league-channel") as Discord.TextChannel;
    welcomeChannel.send(`Sorry ${member}, you had to go :(`);
})

client.on("guildMemberAdd", member =>{ // Need to fix this

    let welcomeChannel = member.guild.channels.find(channel => channel.name === "league-channel") as Discord.TextChannel;
    welcomeChannel.send(`Everyone welcome ${member.displayName} to the channel!`);

    let memberRole = member.guild.roles.find(role => role.id == "578388721393598512");
    member.addRole(memberRole);
    member.send("Thank you for joining the server!");
})

client.on("message", msg =>{
    var count = 0;



    //Ignore the message if it was send by the bot
    if(msg.author.bot){ return; } // Don't allow bot to respond to itself!

    if(msg.channel.type == "dm"){return;}
    
    //Ignore messages that don't start with the prefix !
    if(!msg.content.startsWith(ConfigFile.config.prefix)){return;}

    //Handle the command
    handleCommand(msg);


})


async function handleCommand(msg: Discord.Message){
    //Split the string into the command and all of the args
    let command = msg.content.split(" ")[0].replace(ConfigFile.config.prefix, "").toLowerCase();
    let args = msg.content.split(" ").slice(1);

    for(const commandClass of commands){
        //Attempt to execute but ready for error
        try{
            //Check if command class is the correct one for command
            if(!commandClass.isThisCommand(command)){
                //Skip to next iteration if it isn't the correct command class
                continue;
            }
            //Pause execution
            await commandClass.runCommand(args, msg, client);
        }
        catch(exception){
            //If an error occurs log exception
            console.log(exception);
        }

    }
}

function loadCommands(commandsPath: string){

    // Exit if no commands
    if(!ConfigFile.config || (ConfigFile.config.commands as string[]).length === 0) {return;}
    
    //Loop through all of the commands in the config file
    for(const commandName of ConfigFile.config.commands as string[]){
        //Load the command class
        const commandsClass = require(`${commandsPath}/${commandName}`).default;
        
        //Cast as our custome IBotCommand interface
        const command = new commandsClass as IBotCommand;

        //Add our commands list for later when commands are used
        commands.push(command);
    }
}

client.login(ConfigFile.config.token); // turns the bot on by passing the token
