import * as Discord from "discord.js";
import { IBotCommand } from "../api";

export default class purge implements IBotCommand {
    
    private readonly _command = "purge";

    help(): string {
        return "(Admin Only) Deletes the desired number of messages from the channel";
    }
    isThisCommand(command: string): boolean {
        return command === this._command
    }
    async runCommand(args: string[], msgObject: Discord.Message, client: Discord.Client): Promise<void> {
        
        // Clean up of messages
        msgObject.delete(0)
            .catch(console.error);

        //Check if the member has permission
        if(!msgObject.member.hasPermission("ADMINISTRATOR")){
            msgObject.channel.send(`${msgObject.author.username} tried to purge the chat, but does not have permission to do so`)
                .then(msg =>{
                    (msg as Discord.Message).delete(10000) // delete this message after 5 seconds
                        .catch(console.error);
                });
            return;
        }
        //Check is number of messages to delete has been stated
        if(!args[0]){
            msgObject.channel.send(`Usage: !purge [Number of Messages]`)
                .then(msg =>{
                    (msg as Discord.Message).delete(10000) // delete this message after 5 seconds
                        .catch(console.error);
                });
            return;
        }

        let numberOfMessagesToDelete = Number(args[0]);

        //Make sure numberOfMessageToDelete is a number
        if(isNaN(numberOfMessagesToDelete))
        {
            msgObject.channel.send(`Usage: !purge [Number of Messages Less Than 100]`)
                .then(msg =>{
                    (msg as Discord.Message).delete(10000) // delete this message after 5 seconds
                        .catch(console.error);
                });
            return;
        }

        //Make sure the number is an integer
        numberOfMessagesToDelete = Math.round(numberOfMessagesToDelete + 1);

        if(numberOfMessagesToDelete > 100)
        {
            msgObject.channel.send(`Usage: !purge [Number of Messages Less Than 100]`)
                .then(msg =>{
                    (msg as Discord.Message).delete(10000) // delete this message after 5 seconds
                        .catch(console.error);
                });
            return;
        }

        //Actually performing the delete
        msgObject.channel.bulkDelete(numberOfMessagesToDelete)
        .catch(console.error);
    }
}