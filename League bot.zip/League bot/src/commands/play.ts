import * as Discord from "discord.js";
import { IBotCommand } from "../api";
import * as YTDL from "ytdl-core";
import * as searchYT from "yt-search";


export default class play implements IBotCommand {
    
    private readonly _command = "play";

    help(): string {
        //used to explain the use of the command
        return "Explain what the command does"
    }
    isThisCommand(command: string): boolean {
        //Check if it is a command
        return command === this._command
    }
    async runCommand(args: string[], msgObject: Discord.Message, client: Discord.Client): Promise<void> {
        let songSearch = args.slice(1).join(" ");
                
    }
}