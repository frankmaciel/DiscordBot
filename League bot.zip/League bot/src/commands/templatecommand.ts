import * as Discord from "discord.js";
import { IBotCommand } from "../api";

export default class templatecommand implements IBotCommand {
    
    private readonly _command = "testcommand";

    help(): string {
        //used to explain the use of the command
        return "Explain what the command does"
    }
    isThisCommand(command: string): boolean {
        //Check if it is a command
        return command === this._command
    }
    async runCommand(args: string[], msgObject: Discord.Message, client: Discord.Client): Promise<void> {
        
    }
}