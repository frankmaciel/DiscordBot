import * as Discord from "discord.js";
import { IBotCommand } from "../api";

export default class serverinfo implements IBotCommand {
    
    private readonly _command = "serverinfo";

    help(): string {
        //used to explain the use of the command
        return "Returns Some Basic Server Information"
    }
    isThisCommand(command: string): boolean {
        //Check if it is a command
        return command === this._command
    }
    async runCommand(args: string[], msgObject: Discord.Message, client: Discord.Client): Promise<void> {
        
        var admins = "";

        //Loop through each member
        msgObject.guild.members.forEach(member => {

            //Check if they have administrative permissions
            if(member.hasPermission("ADMINISTRATOR")){
                //Append Admins
                admins = admins + "\n" + member.user.username;
            }
            
        })

        let embed = new Discord.RichEmbed()
            .setColor("GOLD")
            .setTitle("Server Info")
            .addField("Member Count", `${msgObject.guild.memberCount}`)
            .addField("Admin(s)", `${admins}`)
            .setFooter(" - League Bot")
            .setImage(client.user.avatarURL)
            .setDescription("Welcome To Our Server!\n\n This is an attempt at using Riot Games API to create a League Bot!")
            

        msgObject.channel.send(embed)
        .catch(console.error);
    }
}