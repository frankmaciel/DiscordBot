import * as Discord from "discord.js";
import { IBotCommand } from "../api";

export default class poll implements IBotCommand {
    
    private readonly _command = "poll";

    help(): string {
        //used to explain the use of the command
        return "A command for starting a poll";
    }
    isThisCommand(command: string): boolean {
        //Check if it is a command
        return command === this._command
    }
    async runCommand(args: string[], msgObject: Discord.Message, client: Discord.Client): Promise<void> {
        //Clean up of the command entered
        msgObject.delete(0)
            .catch(console.error);
        
        //if the person only entered the command
        if(args.length < 1) { return; }

        //Creating the poll
        let pollEmbed = new Discord.RichEmbed()
            .setTitle(`${msgObject.author.username}'s Poll`)
            .setDescription(args.join(" "))
            
        msgObject.channel.send("You will only have 10 seconds to answer!")
            .then(msg=>{
                (msg as Discord.Message).delete(11000);
            });
        
        //Take as long as you need to send the pollEmbed before moving on
        let pollMessage = await msgObject.channel.send(pollEmbed)
            .catch(console.error)
        

        //We do this because we cannot react on a embed, but we can on a message!
        await (pollMessage as Discord.Message).react("👍")
            .catch(console.error);
        await (pollMessage as Discord.Message).react("👎")
            .catch(console.error);

        //Filters the two reactions
        const filter = (reaction: Discord.MessageReaction) => reaction.emoji.name === '👍' || reaction.emoji.name === '👎'; 
        //Sets the results
        const results = await (pollMessage as Discord.Message).awaitReactions(filter, {time: 10000});

        //Creating the resulting embed to print
        let resultsEmbed = new Discord.RichEmbed()
        .setTitle(`${msgObject.author.username}'s Poll Results For ${args.join(" ")}`)
        .addField("👍:", `${(results.get("👍").count)-1} Votes`)
        .addField("👎:", `${(results.get("👎").count)-1} Votes`)
        .setColor("RANDOM");

        msgObject.channel.send(resultsEmbed)
            .then(msg=>{
                (msg as Discord.Message).delete(15000);
            });

        //deletes poll message which we set as a discord message again so that we may delete it!
        (pollMessage as Discord.Message).delete(0)
            .catch(console.error);
        
        
        

    }
}