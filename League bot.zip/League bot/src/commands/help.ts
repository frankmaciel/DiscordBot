import * as Discord from "discord.js";
import * as ConfigFile from "../config"
import { IBotCommand } from "../api";

export default class help implements IBotCommand {
    
    private readonly _command = "help";

    help(): string {
        //used to explain the use of the command
        return "Will Print Out All The Commands";
    }
    isThisCommand(command: string): boolean {
        //Check if it is a command
        return command === this._command
    }
    async runCommand(args: string[], msgObject: Discord.Message, client: Discord.Client): Promise<void> {
        var commands = "";

        msgObject.delete(0)
            .catch(console.error);

        (ConfigFile.config.commands as string[]).forEach(command => {
            commands = commands + '[' + '!'+ command + ']' + '\n' + '\n';
        });

        msgObject.channel.send(`${commands}`)
            .then(msg => {
                (msg as Discord.Message).delete(10000)
                    .catch(console.error);
            })
    }
}