import * as Discord from "discord.js";
import { IBotCommand } from "../api";

export default class kick implements IBotCommand {
    
    private readonly _command = "kick";

    help(): string {
        return "(Admin Only) Kicks user who is mentioned";
    }

    isThisCommand(command: string): boolean {
        return command === this._command;
    }

    async runCommand(args: string[], msgObject: Discord.Message, client: Discord.Client): Promise<void> {
        
        //Get the member to kick and get the reasoning behind it
        let mentionedUser = msgObject.mentions.users.first();
        let suppliedReason = args.slice(1).join(" ") || "";
        let kickLog = `${msgObject.author.username}: ${suppliedReason}`;

        //Clean-up command message
        msgObject.delete(5000)
            .catch(console.error);

        
        //Make sure an administrator is using the command
        if(!msgObject.member.hasPermission("ADMINISTRATOR")){
            msgObject.channel.send(`${msgObject.author.username} tried to kick ${mentionedUser.username}, but does not have permission to do so.`)
                .then(msg => {
                    (msg as Discord.Message).delete(10000)
                        .catch(console.error);
                });
            return;
        }
        // Make sure there is actually a mentioned user able to be kicked
        if(!mentionedUser){
            msgObject.channel.send(`User not found! OR Incorrect Usage!\n\nUsage: !kick @{User's Name} {Supplied Reason}`)
            .then(msg => {
                (msg as Discord.Message).delete(10000)
                    .catch(console.error);
            });
            return;
        }

        //Kick the member with the reason supplied
        msgObject.guild.member(mentionedUser).kick(kickLog)
            .then(console.log)
            .catch(console.error)

    }


}